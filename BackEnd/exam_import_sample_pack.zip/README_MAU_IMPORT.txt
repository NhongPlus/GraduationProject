BO MAU IMPORT DE THI

File dinh kem:
1. exam_template_GiaoVien.docx
2. exam_template_media_samples.zip

Cach test nhanh:
- Mo file Word mau va import len he thong
- Neu co media, chon them file ZIP media mau di kem
- He thong se tu doi chieu:
  * [ANH:code_python_loop.png]
  * [AUDIO:python_question_01.wav]
  * [VIDEO:python_demo_01.mp4]

Luu y:
- Ten file trong ZIP phai khop voi the trong Word
- He thong khong phan biet hoa/thuong va bo qua thu muc con
- Space / "-" / "_" duoc coi la tuong duong khi doi chieu
