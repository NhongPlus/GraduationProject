BỘ MẪU IMPORT ĐỀ THI

File đính kèm:
1. exam_template_GiaoVien.docx
2. exam_template_media_samples.zip

Cách test nhanh:
- Mở file Word mẫu và import lên hệ thống
- Nếu có media, chọn thêm file ZIP media mẫu đi kèm
- Hệ thống sẽ tự đối chiếu:
  * [ANH:code_python_loop.png]
  * [AUDIO:python_question_01.wav]
  * [VIDEO:python_demo_01.mp4]

Lưu ý:
- Tên file trong ZIP phải khớp với thẻ trong Word
- Hệ thống không phân biệt hoa/thường và bỏ qua thư mục con
- Space / "-" / "_" được coi là tương đương khi đối chiếu
